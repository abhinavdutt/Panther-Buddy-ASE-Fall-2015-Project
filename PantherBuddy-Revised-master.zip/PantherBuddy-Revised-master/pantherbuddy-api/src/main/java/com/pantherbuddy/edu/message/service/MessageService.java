package com.pantherbuddy.edu.message.service;

import javax.ejb.Local;


@Local
public interface MessageService {

}
