package com.pantherbuddy.edu.message.to;

public class MessageTo {

}
