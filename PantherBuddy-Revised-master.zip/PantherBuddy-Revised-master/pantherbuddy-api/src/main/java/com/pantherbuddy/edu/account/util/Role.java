package com.pantherbuddy.edu.account.util;

public enum Role {
	ADMIN,REG_USER;
}
