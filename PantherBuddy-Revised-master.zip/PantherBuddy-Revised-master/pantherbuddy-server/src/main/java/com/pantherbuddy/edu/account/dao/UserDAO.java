package com.pantherbuddy.edu.account.dao;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;

import com.pantherbuddy.edu.account.entity.User;

@LocalBean
@Stateless
public class UserDAO {

	public User getUserByEMail(String email){
		// TODO need to implement.
		return null;
	}

	public User saveUser(User user){
		// TODO need to implement.
		return null;
	}

	public User getUserById(Long id){
		// TODO need to implement.
		return null;
	}

}
