package com.pantherbuddy.edu.account.util;

public final class PasswordGenerator {

	public static String generatePassword(){
		// TODO need to implement.
		return null;
	}
}
